package com.fahim.hw.hw5.two;

public class House extends Building{

    private String mailAddress;

    public House(String name) {
        super(name);
    }
}
