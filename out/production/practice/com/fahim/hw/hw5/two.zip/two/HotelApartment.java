package com.fahim.hw.hw5.two;

public class HotelApartment extends Building{

    int numberOfCleaningStaff;
    public HotelApartment(String name) {
        super(name);
    }
}
