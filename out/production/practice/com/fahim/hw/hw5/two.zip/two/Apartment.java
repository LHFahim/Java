package com.fahim.hw.hw5.two;

public class Apartment extends Building {

    private String manager;
    public Apartment(String name) {
        super(name);
    }
}
