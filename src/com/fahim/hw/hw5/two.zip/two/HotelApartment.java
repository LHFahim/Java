package com.fahim.hw.hw5.two;

public class HotelApartment extends Apartment{

    int numberOfCleaningStaff;
    public HotelApartment(String name) {
        super(name);
    }
}
